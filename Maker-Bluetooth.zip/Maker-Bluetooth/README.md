# Maker-Bluetooth
Aplicação em Android para gerenciar conexões e trocar informações com dispositivos embarcados Arduino.

Este App tem propósitos educacionais com o objetivo de apresentar uma aplicação em Android 
para permitir a troca de informações, com protótipos em Arduino equipados com Bluetooth, 
criados em sala de aula por alunos dos cursos técnicos de Informática, Eletrônica e áreas correlatas a tecnologia. 
A ferramenta criada com recursos, além do informacional, oferece aos alunos, no processo de ensino e de aprendizagem, 
interação com diversos dispositivos embarcados e componentes eletrônicos. Como resultado, destaca-se que o aplicativo 
proposto permita criar e configurar diversos tipos de interfaces gráficas para se conectar e trocar informações, 
lidando com questões de usabilidade e facilidade na programação.
