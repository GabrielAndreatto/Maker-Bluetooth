package br.com.example.andreatto.tccmakerbluetooth.views.terminal.chat;

public class TerminalPojo {

    public TerminalMsg terminalMsg;

    public TerminalPojo() {}

    public TerminalMsg getTerminalMsg() {
        return terminalMsg = new TerminalMsg();
    }
}
