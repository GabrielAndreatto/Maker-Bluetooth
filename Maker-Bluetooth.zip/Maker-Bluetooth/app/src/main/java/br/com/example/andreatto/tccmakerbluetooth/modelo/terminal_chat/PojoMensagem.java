package br.com.example.andreatto.tccmakerbluetooth.modelo.terminal_chat;

public class PojoMensagem {

    public MensagensPojo mensagensPojo;

    public PojoMensagem() {}

    public MensagensPojo getMensagensPojo() {
        return mensagensPojo = new MensagensPojo();
    }

}
