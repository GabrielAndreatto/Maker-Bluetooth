package br.com.example.andreatto.tccmakerbluetooth.views.terminal.chat;

public class TerminalMsg {

    private String mensagem;
    private int code;

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
