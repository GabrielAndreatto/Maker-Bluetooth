package br.com.example.andreatto.tccmakerbluetooth.util.bluetooth.classes;

public class TextTools {
    static String toUpperFirstCase(String message) {
        return message.substring(0,1).toUpperCase() + message.substring(1);
    }
}
